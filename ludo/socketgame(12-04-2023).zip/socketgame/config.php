<?php

    define("DB_HOST", "localhost");
    define("DB_NAME", "ludo");
    define("DB_USERNAME", "root");
    define("DB_PASSWORD", "");

    define('SOCKET_HOST_NAME',"http://localhost/"); 
    define('SOCKET_PORT',"8090");
?>