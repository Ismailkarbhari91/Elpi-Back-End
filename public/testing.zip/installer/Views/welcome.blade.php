<html>

    <body>

        <div class="container welcome" id="welcome">
            <div class="initial-display">
                <p>Welcome to Bagisto</p>

                <div class="content">
                    <div class="content-container" style="padding: 20px">
                        <span>
                            Have you ever heard of an old saying, “No man is an island”? We probably heard that a million times. That saying is actually true because when we became successful, we usually achieve that because someone has helped us. And our thank-you speech skills could be the best thing we can do in return. You may also see
                        </span>

                        <div class="title">
                            INTRODUCTION
                        </div>

                        <span>
                            Have you ever heard of an old saying, “No man is an island”? We probably heard that a million times. That saying is actually true because when we became successful, we usually achieve that because someone has helped us. And our thank-you speech skills could be the best thing we can do in return. You may also see
                        </span>
                    </div>
                </div>

                <div>
                    <button type="button" class="prepare-btn" id="welcome-check">Accept</button>
                </div>
            </div>
        </div>

    </body>

</html>











